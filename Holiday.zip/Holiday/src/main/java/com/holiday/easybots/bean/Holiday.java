package com.holiday.easybots.bean;

import com.jfinal.plugin.activerecord.Model;

public class Holiday extends Model<Holiday> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
