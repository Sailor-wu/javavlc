package com.holiday.bean;

import java.util.Date;

public class Year {

	private String name;// 假日
	private String startday;// 开始日期
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getStartday() {
		return startday;
	}
	public void setStartday(String startday) {
		this.startday = startday;
	}
	
}
